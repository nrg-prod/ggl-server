package com.ggl.bo;



public interface InvBo {
	
	
	public String after8ComeOutSaveTempPublic();
}
