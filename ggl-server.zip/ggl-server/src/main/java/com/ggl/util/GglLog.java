package com.ggl.util;
import org.slf4j.Logger;


public interface GglLog {
	Logger logger=null;//Logger.getLogger(GglDaoImpl.class);

}
